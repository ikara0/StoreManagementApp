﻿using BilgeAdam.Common.Contracts;
using BilgeAdam.Data;
using InformationModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFABilgeAdam.StoreManagementMain
{
    public partial class frmManageUser : Form
    {
        private BindingList<User> users;
        public frmManageUser()
        {
            users = CommanConstant.userList;
            InitializeComponent();
        }

        private void frmManageUser_Load(object sender, EventArgs e)
        {
            dgvUserList.DataSource = users;
        }

      
    }
}
