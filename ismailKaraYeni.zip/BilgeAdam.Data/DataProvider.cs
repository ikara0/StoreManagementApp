﻿using BilgeAdam.Common.Contracts;
using InformationModels;
using InformationModels.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BilgeAdam.Data
{
    public static class DataProvider
    {
        private static BindingList<User> users;
        private static BindingList<Product> products;

        public static object GetData(Type type)
        {

            if(type == typeof(User))
            {
                return ReadUserData();
            }
            else if (type == typeof(Product))
            {
                return ReadProductData();
            }
            return null;
              
        }

        private static object ReadProductData()
        {
            if(products is null)
            {
                products = new BindingList<Product>();
                var product = new Product("Mavi", "MaviJNS", 299.75M, new User() { Email = AuthenticatedUser.Email }, DateTime.Now, Category.Jeans);
                var product2 = new Product("Zara", "ZRN11", 199.75M, new User() { Email = AuthenticatedUser.Email }, DateTime.Now, Category.Jacket);
                products.Add(product);
                products.Add(product2);
            }
            return products;
        }

        private static object ReadUserData()
        {
            if(users is null) 
            {
                users = new BindingList<User>();
                var u1 = new User { Name = "Sergen Kahraman", Password = "123", Email = "sergen@", UserRole = UserRole.Admin };
                var u2 = new User { Name = "İsmail Kara", Password = "123", Email = "ismail@", UserRole = UserRole.SuperCustomer };
                var u3 = new User { Name = "Tufan Yıldırım", Password = "123", Email = "tufan@", UserRole = UserRole.LimitedCustomer };
                var u4 = new User { Name = "Esengül Özkul", Password = "123", Email = "esengül@", UserRole = UserRole.Admin };
                var u5 = new User { Name = "Metehan Çam", Password = "123", Email = "metehan@", UserRole = UserRole.LimitedCustomer };

                users.Add(u1);
                users.Add(u2);
                users.Add(u3);
                users.Add(u4);
                users.Add(u5);

            }
            return users;
        }
       
    }
}
